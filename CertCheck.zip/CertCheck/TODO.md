# TODO - Web Frontend for CertCheck

## Step 1
- [x] Repo analysis: understand `certcheck.py` and available functions.

## Step 2
- [x] Plan confirmed: FastAPI backend + simple HTML/JS frontend.

## Step 3
- [x] Create backend `webapp.py` that exposes:
  - `GET /` serving the frontend HTML
  - `POST /api/check` accepting `{ "urls": [...] }` and calling `check_certificate`

## Step 4
- [x] Create frontend files:
  - `templates/index.html`
  - `static/app.js`
  - `static/style.css`

## Step 5
- [ ] Add run instructions to `README.md` (local localhost:8000)


## Step 6
- [ ] Install dependencies (fastapi, uvicorn) and test via browser



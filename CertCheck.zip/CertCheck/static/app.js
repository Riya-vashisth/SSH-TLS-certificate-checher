const urlsEl = document.getElementById('urls');
const debugEl = document.getElementById('debug');
const checkBtn = document.getElementById('checkBtn');
const statusEl = document.getElementById('status');
const outputEl = document.getElementById('output');

function parseUrls(text) {
  // Split by newlines or commas
  return text
    .split(/\r?\n|,/g)
    .map((s) => s.trim())
    .filter(Boolean);
}

function setLoading(isLoading) {
  checkBtn.disabled = isLoading;
  statusEl.textContent = isLoading ? 'Checking...' : '';
}

checkBtn.addEventListener('click', async () => {
  const urls = parseUrls(urlsEl.value);
  const debug = debugEl.checked;

  if (urls.length === 0) {
    statusEl.textContent = 'Please enter at least 1 URL.';
    outputEl.textContent = 'No results yet.';
    return;
  }

  setLoading(true);
  outputEl.textContent = 'Working...';

  try {
    const res = await fetch('/api/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ urls, debug }),
    });

    const data = await res.json();

    if (!data.ok) {
      outputEl.textContent = JSON.stringify(data, null, 2);
      statusEl.textContent = 'Failed.';
      return;
    }

    outputEl.textContent = JSON.stringify(data.results, null, 2);
    statusEl.textContent = 'Done.';
  } catch (err) {
    statusEl.textContent = 'Request failed.';
    outputEl.textContent = String(err);
  } finally {
    setLoading(false);
  }
});

